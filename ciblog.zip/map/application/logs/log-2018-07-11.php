<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-07-11 19:10:06 --> No URI present. Default controller set.
ERROR - 2018-07-11 19:10:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1698): Access denied for user 'root'@'localhost' /var/www/html/khanafi/map/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2018-07-11 19:10:06 --> Severity: error --> Exception: Unable to connect to the database. /var/www/html/khanafi/map/system/database/DB_driver.php 433
DEBUG - 2018-07-11 19:11:38 --> No URI present. Default controller set.
ERROR - 2018-07-11 19:11:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'siblog' /var/www/html/khanafi/map/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2018-07-11 19:11:38 --> Severity: error --> Exception: Unable to connect to the database. /var/www/html/khanafi/map/system/database/DB_driver.php 433
DEBUG - 2018-07-11 19:11:48 --> No URI present. Default controller set.
ERROR - 2018-07-11 19:11:48 --> Query error: Table 'ciblog.ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = 'af6c9a1eea4da64571f1662c2693358377959589'
DEBUG - 2018-07-11 19:20:36 --> No URI present. Default controller set.
DEBUG - 2018-07-11 19:21:16 --> No URI present. Default controller set.
DEBUG - 2018-07-11 19:21:49 --> No URI present. Default controller set.
DEBUG - 2018-07-11 19:22:01 --> No URI present. Default controller set.
DEBUG - 2018-07-11 19:22:28 --> No URI present. Default controller set.
DEBUG - 2018-07-11 19:22:40 --> No URI present. Default controller set.
DEBUG - 2018-07-11 19:23:06 --> No URI present. Default controller set.
ERROR - 2018-07-11 19:23:12 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians() ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians() ) + sin( radians() ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = 1
    HAVING distance <= 30
    ORDER BY distance ASC
      
ERROR - 2018-07-11 19:23:14 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians() ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians() ) + sin( radians() ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = 1
    HAVING distance <= 30
    ORDER BY distance ASC
      
DEBUG - 2018-07-11 19:23:26 --> No URI present. Default controller set.
ERROR - 2018-07-11 19:24:11 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians() ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians() ) + sin( radians() ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = 2
    HAVING distance <= 30
    ORDER BY distance ASC
      
