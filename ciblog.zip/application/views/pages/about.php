<h2><?= $title ?></h2>
<p>This is ciBlog version 1.0</p>